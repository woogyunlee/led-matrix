/*
 * cdc.c
 *
 *  Created on: 2020. 12. 11.
 *      Author: baram
 */


#include "cdc.h"


#ifdef _USE_HW_CDC


bool cdcInit(void)
{
  bool ret = true;


  return ret;
}


#endif
